package com.example.traderjoes20.Models;

public class Equipment {
    public int id;
    public String name;
    public String localizedName;
    public String image;
    public Temperature temperature;
}
