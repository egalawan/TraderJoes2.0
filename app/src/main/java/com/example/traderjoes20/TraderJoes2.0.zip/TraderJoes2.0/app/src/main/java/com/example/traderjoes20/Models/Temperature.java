package com.example.traderjoes20.Models;

public class Temperature {
    public double number;
    public String unit;
}
