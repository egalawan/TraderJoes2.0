package com.example.traderjoes20.Models;

public class Length {
    public int number;
    public String unit;
}
