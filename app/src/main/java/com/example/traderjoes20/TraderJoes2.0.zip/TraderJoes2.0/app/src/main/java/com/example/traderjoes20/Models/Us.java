package com.example.traderjoes20.Models;

public class Us {
    public double amount;
    public String unitShort;
    public String unitLong;
}
